
-- Creating retirement_titles table
SELECT e.emp_no , e.first_name , e.last_name,
t.title , t.from_date, t.to_date
INTO retirement_titles
FROM employees AS e 
INNER JOIN titles as t
ON t.emp_no = e.emp_no
WHERE e.birth_date BETWEEN '1952-01-01' AND '1955-12-31'
ORDER BY e.emp_no ASC


-- Use Dictinct with Orderby to remove duplicate rows

SELECT DISTINCT ON (emp_no) emp_no,
first_name,
last_name,
title
INTO unique_titles
FROM retirement_titles
WHERE to_date = '9999-01-01'
ORDER BY emp_no ASC;
-- data table of unique title

select * from unique_titles;


--  retrieve the number of employees by their most recent job title who are about to retire.

SELECT COUNT(title) , title
INTO retiring_titles
FROM unique_titles
GROUP by title
ORDER by COUNT(title) DESC;

--- data table of retiring titles

select * from retiring_titles;

-- to retrieve mentorship eligibilty 

SELECT DISTINCT ON (e.emp_no) e.emp_no , e.first_name , e.last_name ,
e.birth_date ,de.from_date , de.to_date , t.title
INTO mentorship_eligibilty
From employees AS e
INNER JOIN dept_emp AS de
ON de.emp_no = e.emp_no
INNER JOIN titles as t
ON t.emp_no = de.emp_no
WHERE (de.to_date = '9999-01-01') 
AND (e.birth_date BETWEEN '1965-01-01' AND '1965-12-31')
ORDER BY e.emp_no ASC;